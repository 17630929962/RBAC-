﻿using RightControl.IRepository;
using RightControl.Model;

namespace RightControl.Repository.SysSet
{
    public class LogRepository :BaseRepository<LogModel>, ILogRepository
    {

    }
}
