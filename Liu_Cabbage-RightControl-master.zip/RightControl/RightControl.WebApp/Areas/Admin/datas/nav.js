﻿var navs = [ {
    "title": "权限管理",
    "icon": "icon-setting-permissions",
    "spread": true,
    "children": [
    {
        "title": "菜单管理",
        "icon": "icon-caidan",
        "href": "/permissions/menu",
        "children": [
   {
       "title": "菜单1",
       "icon": "icon-caidan",
       "href": "/permissions/menu"
   }]
    }, {
        "title": "角色管理",
        "icon": "icon-jiaoseguanli",
        "href": "/permissions/role"
    }, {
        "title": "用户管理",
        "icon": "icon-yonghu",
        "href": "/permissions/user"
    }]
}, {
    "title": "系统设置",
    "icon": "icon-xitong",
"spread": true,
"children": [
{
    "title": "网站设置",
    "icon": "icon-ditu",
    "href": "/sysset/website"
}, {
    "title": "基本资料",
    "icon": "icon-jibenziliao",
    "href": "/SysSet/info"
},{
    "title": "修改密码",
    "icon": "icon-xiugaimima",
    "href": "/SysSet/password"
}, {
    "title": "日志管理",
    "icon": "icon-xitongrizhi",
    "href": "/SysSet/Log"
}]
}];