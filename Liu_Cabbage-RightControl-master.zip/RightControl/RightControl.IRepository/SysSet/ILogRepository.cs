﻿using RightControl.Model;

namespace RightControl.IRepository
{
    public interface ILogRepository : IBaseRepository<LogModel>
    {

    }
}
